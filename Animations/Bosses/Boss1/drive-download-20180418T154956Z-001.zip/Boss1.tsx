<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Boss1" tilewidth="128" tileheight="128" tilecount="230" columns="23" spacing="0" margin="0">
 <image source="Boss1Animation.png" width="2944" height="1280"/>
</tileset>
