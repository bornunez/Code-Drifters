#pragma once
#include "Component.h"
#include "GameObject.h"



Component::~Component()
{
}
