#include "MasterBoss.h"



MasterBoss::MasterBoss():GameObject()
{
}


MasterBoss::~MasterBoss()
{
}
