#pragma once
#include "Enemy.h"

class ExampleEnemy : public Enemy
{
public:
	ExampleEnemy(MainCharacter* mc);

	~ExampleEnemy();


};

