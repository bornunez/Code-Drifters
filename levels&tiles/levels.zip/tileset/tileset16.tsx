<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Tileset16" tilewidth="16" tileheight="16" spacing="1" margin="1" tilecount="64" columns="8">
 <image source="TilesetConProta.png" trans="ff00ff" width="137" height="137"/>
</tileset>
